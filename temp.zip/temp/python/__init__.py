
from __future__ import annotations

import asyncio
import aiohttp

if __name__ == '__main__':
	pass
